export const metadata = { title: 'Magazine — FK Éditions' }

export default function MagazinePage() {
  return (
    <>
      <section
        className="fk-section"
        style={{ paddingTop: 'clamp(60px, 8vh, 100px)', paddingBottom: 'clamp(40px, 6vh, 60px)' }}
      >
        <div className="fk-container" style={{ textAlign: 'center' }}>
          <span className="kicker" style={{ justifyContent: 'center' }}>FK Éditions</span>
          <h1 className="section-title">
            Le <em className="serif-i">Magazine</em> FK Éditions
          </h1>
        </div>
      </section>

      <section className="fk-section" style={{ paddingTop: 0 }}>
        <div className="fk-container" style={{ maxWidth: 720, textAlign: 'center' }}>
          <h2
            style={{
              fontFamily: 'var(--serif)',
              fontStyle: 'italic',
              fontSize: 'clamp(28px, 3.5vw, 44px)',
              color: 'var(--ink)',
              marginBottom: 28,
            }}
          >
            Bienvenue !
          </h2>
          <div
            style={{
              width: 48,
              height: 2,
              background: 'var(--accent)',
              margin: '0 auto 36px',
            }}
          />
          <p
            style={{
              fontSize: 18,
              lineHeight: 1.7,
              color: 'var(--ink-soft)',
            }}
          >
            Plongez au cœur de nos titres et vibrez au rythme de la culture. Des terrains de sport
            aux scènes musicales, explorez nos grands reportages, nos interviews exclusives et les
            récits de ceux qui font l&apos;époque.
          </p>
          <p
            style={{
              marginTop: 32,
              fontFamily: 'var(--serif)',
              fontStyle: 'italic',
              fontSize: 17,
              color: 'var(--ink-mute)',
            }}
          >
            ✦ Bientôt disponible ✦
          </p>
        </div>
      </section>
    </>
  )
}
