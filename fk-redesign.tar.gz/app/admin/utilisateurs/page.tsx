import { prisma } from '@/lib/prisma'
import RoleToggle from './RoleToggle'

export default async function UtilisateursPage() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: 'desc' },
    include: { _count: { select: { purchases: true } } },
  })

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-serif text-2xl text-cream">Utilisateurs</h1>
        <p className="text-xs text-cream-muted mt-1">{users.length} compte{users.length > 1 ? 's' : ''} enregistré{users.length > 1 ? 's' : ''}</p>
      </div>

      <div className="bg-dark-3 border border-dark-4 overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-dark-4 text-cream-muted">
              <th className="text-left px-4 py-3 font-medium">Nom</th>
              <th className="text-left px-4 py-3 font-medium">Email</th>
              <th className="text-left px-4 py-3 font-medium">Rôle</th>
              <th className="text-left px-4 py-3 font-medium">Achats</th>
              <th className="text-left px-4 py-3 font-medium">Inscrit le</th>
              <th className="text-right px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-b border-dark-4 hover:bg-dark-4/30 transition-colors">
                <td className="px-4 py-3 text-cream-dim">{user.name ?? '—'}</td>
                <td className="px-4 py-3 text-cream-dim">{user.email}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 text-[10px] uppercase tracking-wide ${
                    user.role === 'ADMIN'
                      ? 'bg-gold/10 text-gold border border-gold/30'
                      : 'bg-dark-4 text-cream-muted border border-dark-4'
                  }`}>
                    {user.role === 'ADMIN' ? 'Admin' : 'Client'}
                  </span>
                </td>
                <td className="px-4 py-3 text-cream-muted">{user._count.purchases}</td>
                <td className="px-4 py-3 text-cream-muted">
                  {new Date(user.createdAt).toLocaleDateString('fr-FR')}
                </td>
                <td className="px-4 py-3 text-right">
                  <RoleToggle userId={user.id} currentRole={user.role} userEmail={user.email} />
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-cream-muted">Aucun utilisateur</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
