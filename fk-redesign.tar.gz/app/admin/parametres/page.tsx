'use client'

import { useState, useEffect } from 'react'

export default function ParametresPage() {
  const [prices, setPrices] = useState({ plan_1m_price: '4', plan_3m_price: '8', plan_6m_price: '16', plan_12m_price: '20' })
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    fetch('/api/admin/settings')
      .then((r) => r.json())
      .then((data) => {
        if (data.plan_1m_price) setPrices({
          plan_1m_price: data.plan_1m_price,
          plan_3m_price: data.plan_3m_price,
          plan_6m_price: data.plan_6m_price,
          plan_12m_price: data.plan_12m_price,
        })
      })
      .catch(() => {})
  }, [])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setSuccess(false)
    await fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(prices),
    })
    setSaving(false)
    setSuccess(true)
    setTimeout(() => setSuccess(false), 3000)
  }

  const planLabels = [
    { key: 'plan_1m_price', label: '1 mois' },
    { key: 'plan_3m_price', label: '3 mois' },
    { key: 'plan_6m_price', label: '6 mois' },
    { key: 'plan_12m_price', label: '12 mois' },
  ]

  return (
    <div className="max-w-lg">
      <div className="mb-8">
        <h1 className="font-serif text-2xl text-cream">Paramètres</h1>
        <p className="text-xs text-cream-muted mt-1">Prix des abonnements à la revue</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="bg-dark-3 border border-dark-4 p-6 space-y-4">
          {planLabels.map(({ key, label }) => (
            <div key={key} className="flex items-center gap-4">
              <label className="text-sm text-cream w-20 shrink-0">{label}</label>
              <div className="flex items-center gap-2 flex-1">
                <input
                  type="number"
                  min="1"
                  step="0.01"
                  value={prices[key as keyof typeof prices]}
                  onChange={(e) => setPrices((p) => ({ ...p, [key]: e.target.value }))}
                  className="w-28 bg-dark border border-dark-4 focus:border-gold/50 text-cream text-sm px-3 py-2 outline-none transition-colors text-right"
                />
                <span className="text-xs text-cream-muted">$ USD</span>
              </div>
            </div>
          ))}
        </div>

        {success && (
          <div className="bg-green-500/10 border border-green-500/30 text-green-400 text-xs px-4 py-3">
            Prix mis à jour avec succès.
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="bg-gold hover:bg-gold-light text-dark font-semibold px-6 py-3 text-xs uppercase tracking-widest transition-colors disabled:opacity-60"
        >
          {saving ? 'Enregistrement…' : 'Enregistrer les prix'}
        </button>
      </form>
    </div>
  )
}
