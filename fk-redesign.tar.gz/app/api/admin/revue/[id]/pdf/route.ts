import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { writeFile, mkdir, readFile } from 'fs/promises'
import path from 'path'
import { normalizePdf } from '@/lib/normalizePdf'

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (session?.user?.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 403 })
  }

  const { id } = await params
  const issue = await prisma.revueIssue.findUnique({ where: { id } })
  if (!issue?.pdfFile) {
    return NextResponse.json({ error: 'Aucun PDF' }, { status: 404 })
  }

  const safeName = path.basename(issue.pdfFile)
  const filePath = path.join(process.cwd(), 'private', 'revues', safeName)

  try {
    const file = await readFile(filePath)
    return new Response(file, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${issue.title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf"`,
        'Content-Length': file.length.toString(),
      },
    })
  } catch {
    return NextResponse.json({ error: 'Fichier introuvable' }, { status: 404 })
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (session?.user?.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 403 })
  }

  const { id } = await params
  const buffer = Buffer.from(await req.arrayBuffer())

  if (buffer.length === 0) {
    return NextResponse.json({ error: 'Fichier vide' }, { status: 400 })
  }

  const dir = path.join(process.cwd(), 'private', 'revues')
  await mkdir(dir, { recursive: true })
  const filename = `revue-${id}-${Date.now()}.pdf`
  const fullPath = path.join(dir, filename)
  await writeFile(fullPath, buffer)
  await normalizePdf(fullPath)

  await prisma.revueIssue.update({
    where: { id },
    data: { pdfFile: filename },
  })

  return NextResponse.json({ success: true, filename })
}
