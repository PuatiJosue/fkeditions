import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (session?.user?.role !== 'ADMIN') return null
  return session
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
  const { id } = await params

  const buffer = Buffer.from(await req.arrayBuffer())
  const contentType = req.headers.get('content-type') ?? 'image/jpeg'
  const ext = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg'

  const dir = path.join(process.cwd(), 'public', 'uploads', 'authors')
  await mkdir(dir, { recursive: true })

  const filename = `${id}.${ext}`
  await writeFile(path.join(dir, filename), buffer)

  const photo = `/uploads/authors/${filename}`
  await prisma.author.update({ where: { id }, data: { photo } })

  return NextResponse.json({ photo })
}
