import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (session?.user?.role !== 'ADMIN') return null
  return session
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
  const { id } = await params

  // arrayBuffer() au lieu de FormData : évite la limite de taille de 4MB imposée par Next.js sur les FormData
  const buffer = Buffer.from(await req.arrayBuffer())
  const contentType = req.headers.get('content-type') ?? 'image/jpeg'
  const ext = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg'

  // Stocké dans public/ → accessible directement par le navigateur (images publiques)
  const dir = path.join(process.cwd(), 'public', 'uploads', 'books')
  await mkdir(dir, { recursive: true })

  const filename = `${id}.${ext}`
  await writeFile(path.join(dir, filename), buffer)

  const coverImage = `/uploads/books/${filename}`
  await prisma.book.update({ where: { id }, data: { coverImage } })

  return NextResponse.json({ coverImage })
}
