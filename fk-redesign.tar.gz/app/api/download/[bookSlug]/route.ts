import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { readFile } from 'fs/promises'
import path, { resolve } from 'path'
import { existsSync } from 'fs'
import { verifyToken } from '@/lib/signedToken'

export async function GET(req: Request, { params }: { params: Promise<{ bookSlug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Connexion requise' }, { status: 401 })
  }

  const { bookSlug } = await params
  const token = new URL(req.url).searchParams.get('token')
  if (!session.user.role || session.user.role !== 'ADMIN') {
    if (!token || !verifyToken(token, session.user.id, `book:${bookSlug}`)) {
      return NextResponse.json({ error: 'Token invalide ou expiré' }, { status: 403 })
    }
  }

  if (!/^[a-z0-9-]+$/.test(bookSlug)) {
    return NextResponse.json({ error: 'Requête invalide' }, { status: 400 })
  }

  const isAdmin = session.user.role === 'ADMIN'

  if (!isAdmin) {
    const purchase = await prisma.purchase.findFirst({
      where: { userId: session.user.id, bookSlug, status: 'COMPLETED' },
    })
    if (!purchase) {
      return NextResponse.json({ error: 'Accès refusé — achetez ce livre pour y accéder' }, { status: 403 })
    }
  }

  const book = await prisma.book.findUnique({ where: { slug: bookSlug } })
  if (!book) return NextResponse.json({ error: 'Livre introuvable' }, { status: 404 })

  // Servir ePub en priorité, sinon PDF
  if (book.epubFile) {
    const fileName = path.basename(book.epubFile)
    const basePath = resolve(process.cwd(), 'private', 'epubs')
    const filePath = resolve(basePath, fileName)

    if (!filePath.startsWith(basePath)) {
      return NextResponse.json({ error: 'Requête invalide' }, { status: 400 })
    }
    if (!existsSync(filePath)) {
      return NextResponse.json({ error: 'Fichier introuvable — contactez le support' }, { status: 404 })
    }

    const fileBuffer = await readFile(filePath)
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': 'application/epub+zip',
        'Content-Disposition': `inline; filename="${book.slug}.epub"`,
        'Cache-Control': 'no-store, no-cache, private',
        'X-Content-Type-Options': 'nosniff',
      },
    })
  }

  if (book.pdfFile) {
    const fileName = path.basename(book.pdfFile)
    const basePath = resolve(process.cwd(), 'private', 'pdfs')
    const filePath = resolve(basePath, fileName)

    if (!filePath.startsWith(basePath)) {
      return NextResponse.json({ error: 'Requête invalide' }, { status: 400 })
    }
    if (!existsSync(filePath)) {
      return NextResponse.json({ error: 'Fichier PDF introuvable — contactez le support' }, { status: 404 })
    }

    const fileBuffer = await readFile(filePath)
    return new NextResponse(fileBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${book.slug}.pdf"`,
        'Cache-Control': 'no-store, no-cache, private',
        'X-Content-Type-Options': 'nosniff',
      },
    })
  }

  return NextResponse.json({ error: 'Fichier non disponible pour ce livre' }, { status: 404 })
}
