'use client'

import { useState } from 'react'
import CheckoutSection from '@/components/CheckoutSection'

interface Props {
  bookId: string
  bookTitle: string
  price: number
  pricePhysical?: number | null
  preOrder: boolean
  releaseDate?: string
  successParam?: string
  cancelledParam?: string
}

export default function BookFormatSelector({
  bookId, bookTitle, price, pricePhysical, preOrder, releaseDate, successParam, cancelledParam,
}: Props) {
  const hasPhysical = !!pricePhysical
  const [format, setFormat] = useState<'ebook' | 'physical'>('ebook')

  const activePrice = format === 'ebook' ? price : pricePhysical!
  const activeTitle = hasPhysical
    ? `${bookTitle} — ${format === 'ebook' ? 'Ebook PDF' : 'Livre physique'}`
    : bookTitle

  return (
    <div className="flex flex-col gap-6">
      {/* Sélecteur de format */}
      {hasPhysical && (
        <div className="flex flex-col gap-2">
          <p className="text-xs text-cream-muted uppercase tracking-widest">Choisir le format</p>
          <div className="flex border border-dark-4">
            {(['ebook', 'physical'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFormat(f)}
                className={`flex-1 py-2.5 text-xs tracking-widest uppercase transition-colors ${
                  format === f ? 'bg-gold text-dark font-semibold' : 'text-cream-muted hover:text-cream'
                }`}
              >
                {f === 'ebook' ? `Ebook PDF — ${price} $` : `Livre physique — ${pricePhysical} $`}
              </button>
            ))}
          </div>
          {format === 'physical' && (
            <p className="text-[11px] text-cream-muted/70">
              Notre équipe vous contactera pour organiser la livraison à Kinshasa.
            </p>
          )}
        </div>
      )}

      {/* Prix */}
      <div>
        <p className="text-xs text-cream-muted uppercase tracking-widest mb-1">Prix</p>
        <p className="font-serif text-4xl text-gold font-bold">
          {activePrice} $<span className="text-sm text-cream-muted font-normal ml-1">USD</span>
        </p>
      </div>

      <CheckoutSection
        bookId={bookId}
        bookTitle={activeTitle}
        price={activePrice}
        successParam={successParam}
        cancelledParam={cancelledParam}
        preOrder={preOrder}
        releaseDate={releaseDate}
      />
    </div>
  )
}
